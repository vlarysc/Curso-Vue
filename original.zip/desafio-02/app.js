new Vue({
    el: '#desafio',
    data: {
        valor: ''
    }
})